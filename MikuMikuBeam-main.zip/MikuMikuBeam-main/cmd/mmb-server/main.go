package main

import (
	"context"
	"encoding/base64"
	"flag"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"time"

	"github.com/labstack/echo/v4"
	"github.com/labstack/echo/v4/middleware"
	"github.com/rs/zerolog"
	"github.com/rs/zerolog/log"
	socketio "github.com/zishang520/socket.io/socket"

	mc "github.com/sammwyy/mikumikubeam/internal/attacks/game"
	httpA "github.com/sammwyy/mikumikubeam/internal/attacks/http"
	tcpA "github.com/sammwyy/mikumikubeam/internal/attacks/tcp"
	"github.com/sammwyy/mikumikubeam/internal/config"
	"github.com/sammwyy/mikumikubeam/internal/engine"
	"github.com/sammwyy/mikumikubeam/internal/proxy"
	"github.com/sammwyy/mikumikubeam/pkg/api"
	targetpkg "github.com/sammwyy/mikumikubeam/pkg/target"
)

func main() {
	// logging: default to console (human) unless LOG_FORMAT=json
	if strings.ToLower(os.Getenv("LOG_FORMAT")) != "json" {
		log.Logger = log.Output(zerolog.ConsoleWriter{Out: os.Stderr, TimeFormat: time.RFC3339})
	}

	// flags
	var noProxyFlag bool
	flag.BoolVar(&noProxyFlag, "no-proxy", false, "Allow running without proxies")
	flag.Parse()

	cfg, err := config.Load("")
	if err != nil {
		log.Warn().Err(err).Msg("Could not load config, using defaults")
	}

	// API key authentication
	apiKey := os.Getenv("MMB_API_KEY")
	if apiKey == "" {
		log.Warn().Msg("MMB_API_KEY not set — server is running WITHOUT authentication. Set MMB_API_KEY env var to secure it.")
	}

	e := echo.New()
	e.HideBanner = true
	e.Logger.SetOutput(io.Discard)
	e.Use(middleware.Recover())
	e.Use(middleware.CORSWithConfig(middleware.CORSConfig{
		AllowOrigins: []string{cfg.AllowedOrigin},
		AllowMethods: []string{http.MethodGet, http.MethodPost},
		AllowHeaders: []string{"Content-Type", "Authorization"},
	}))

	// API key middleware for non-static routes
	if apiKey != "" {
		e.Use(func(next echo.HandlerFunc) echo.HandlerFunc {
			return func(c echo.Context) error {
				path := c.Request().URL.Path
				// Skip auth for static files and socket.io (socket.io has its own auth)
				if !strings.HasPrefix(path, "/attacks") &&
					!strings.HasPrefix(path, "/configuration") {
					return next(c)
				}
				auth := c.Request().Header.Get("Authorization")
				if auth != "Bearer "+apiKey {
					return c.JSON(http.StatusUnauthorized, map[string]string{"error": "unauthorized"})
				}
				return next(c)
			}
		})
	}

	// Socket.io server (compatible con v3/v4 clients)
	io := socketio.NewServer(nil, nil)

	reg := engine.NewRegistry()
	reg.Register(engine.AttackHTTPFlood, httpA.NewFloodWorker())
	reg.Register(engine.AttackHTTPBurst, httpA.NewBurstWorker())
	reg.Register(engine.AttackHTTPBypass, httpA.NewBypassWorker())
	reg.Register(engine.AttackHTTPSlowloris, httpA.NewSlowlorisWorker())
	reg.Register(engine.AttackTCPFlood, tcpA.NewFloodWorker())
	reg.Register(engine.AttackTCPBurst, tcpA.NewBurstWorker())
	reg.Register(engine.AttackTCPSlowloris, tcpA.NewSlowlorisWorker())
	reg.Register(engine.AttackMinecraftPing, mc.NewPingWorker())

	eng := engine.NewEngine(*reg)

	proxies, err := proxy.LoadProxies(cfg.ProxiesFile)
	if err != nil {
		log.Warn().Err(err).Str("file", cfg.ProxiesFile).Msg("Could not load proxies")
	}
	uas, err := proxy.LoadUserAgents(cfg.UserAgentsFile)
	if err != nil {
		log.Warn().Err(err).Str("file", cfg.UserAgentsFile).Msg("Could not load user agents")
	}

	// list attacks endpoint
	e.GET("/attacks", func(c echo.Context) error {
		kinds := reg.ListKinds()
		out := make([]string, 0, len(kinds))
		for _, k := range kinds {
			out = append(out, string(k))
		}
		return c.JSON(http.StatusOK, map[string]any{"attacks": out})
	})

	io.On("connection", func(clients ...any) {
		client := clients[0].(*socketio.Socket)

		// Check API key on socket connection if configured
		if apiKey != "" {
			authData := client.Handshake().Auth
			if authData == nil {
				client.Emit("attackError", map[string]any{"message": "Authentication required. Provide API key in auth handshake."})
				client.Disconnect(true)
				return
			}
			if authMap, ok := authData.(map[string]any); ok {
				if key, _ := authMap["apiKey"].(string); key != apiKey {
					client.Emit("attackError", map[string]any{"message": "Invalid API key."})
					client.Disconnect(true)
					return
				}
			} else {
				client.Emit("attackError", map[string]any{"message": "Invalid auth format."})
				client.Disconnect(true)
				return
			}
		}

		client.Emit("stats", map[string]any{
			"pps":          0,
			"proxies":      len(proxies),
			"totalPackets": 0,
			"log":          "Connected to the server.",
		})
		log.Info().Msgf("socket connected id=%s", client.Id())

		allowNoProxy := strings.EqualFold(os.Getenv("ALLOW_NO_PROXY"), "true") || noProxyFlag
		clientID := client.Id()
		attackID := fmt.Sprintf("client-%s", clientID)

		client.On("startAttack", func(datas ...any) {
			if len(datas) == 0 {
				return
			}
			payload, ok := datas[0].(map[string]any)
			if !ok {
				return
			}

			log.Debug().Msgf("startAttack event triggered with payload: %+v", payload)

			toInt := func(v any) int {
				switch t := v.(type) {
				case float64:
					return int(t)
				case int:
					return t
				case string:
					if n, err := strconv.Atoi(t); err == nil {
						return n
					}
				}
				return 0
			}

			req := api.StartAttackRequest{
				Target:       fmt.Sprint(payload["target"]),
				AttackMethod: strings.ToLower(fmt.Sprint(payload["attackMethod"])),
				PacketSize:   toInt(payload["packetSize"]),
				DurationSec:  toInt(payload["duration"]),
				PacketDelay:  toInt(payload["packetDelay"]),
				Threads:      toInt(payload["threads"]),
			}

			// Input validation
			if req.Target == "" {
				client.Emit("attackError", map[string]any{"message": "Target is required"})
				return
			}
			if req.DurationSec < 1 || req.DurationSec > 3600 {
				client.Emit("attackError", map[string]any{"message": "Duration must be between 1 and 3600 seconds"})
				return
			}
			if req.Threads < 0 || req.Threads > 256 {
				client.Emit("attackError", map[string]any{"message": "Threads must be between 0 and 256"})
				return
			}
			if req.PacketDelay < 0 || req.PacketDelay > 10000 {
				client.Emit("attackError", map[string]any{"message": "Packet delay must be between 0 and 10000 ms"})
				return
			}

			// Default packet delay if not specified
			if req.PacketDelay == 0 {
				req.PacketDelay = 50
			}

			log.Info().Msgf("startAttack received: method=%s target=%s duration=%ds delay=%d size=%d threads=%d",
				req.AttackMethod, req.Target, req.DurationSec, req.PacketDelay, req.PacketSize, req.Threads)

			kind := engine.AttackKind(req.AttackMethod)
			filtered := proxy.FilterByMethod(proxies, kind)
			client.Emit("stats", map[string]any{"log": "Using proxies to perform attack.", "proxies": len(filtered)})

			if len(filtered) == 0 && !allowNoProxy {
				msg := "No proxies available; set ALLOW_NO_PROXY=true or --no-proxy to run without proxies"
				log.Warn().Msg(msg)
				client.Emit("attackError", map[string]any{"message": msg})
				return
			}

			tn, err := targetpkg.Parse(req.Target)
			if err != nil {
				client.Emit("attackError", map[string]any{"message": "Invalid target: " + err.Error()})
				return
			}

			params := engine.AttackParams{
				Target:      req.Target,
				TargetNode:  tn,
				Duration:    time.Duration(req.DurationSec) * time.Second,
				PacketDelay: time.Duration(req.PacketDelay) * time.Millisecond,
				PacketSize:  req.PacketSize,
				Method:      kind,
				Threads:     req.Threads,
				Verbose:     true, // Always verbose for web client
			}

			statsCh, err := eng.Start(attackID, context.Background(), params, filtered, uas)
			if err != nil {
				client.Emit("attackError", map[string]any{"message": "Failed to start attack: " + err.Error()})
				return
			}

			log.Info().Msgf("attack started: id=%s method=%s target=%s proxies=%d", attackID, req.AttackMethod, req.Target, len(filtered))
			client.Emit("attackAccepted", map[string]any{"ok": true, "proxies": len(filtered)})

			go func() {
				for st := range statsCh {
					payload := map[string]any{
						"pps":          st.PacketsPerS,
						"proxies":      st.Proxies,
						"totalPackets": st.TotalPackets,
					}
					// Only include log if it's not empty
					if st.Log != "" {
						payload["log"] = st.Log
					}
					client.Emit("stats", payload)
				}
			}()
		})

		client.On("stopAttack", func(...any) {
			eng.Stop(attackID)
			client.Emit("attackEnd")
		})

		client.On("disconnect", func(...any) {
			eng.Stop(attackID)
		})
	})

	// Montar Socket.IO en Echo
	e.Any("/socket.io/*", echo.WrapHandler(io.ServeHandler(nil)))

	// Configuration endpoints
	e.GET("/configuration", func(c echo.Context) error {
		pb, _ := osReadFileSafe(cfg.ProxiesFile)
		ub, _ := osReadFileSafe(cfg.UserAgentsFile)
		return c.JSON(http.StatusOK, api.ConfigurationResponse{
			Proxies: base64.StdEncoding.EncodeToString(pb),
			UAs:     base64.StdEncoding.EncodeToString(ub),
		})
	})

	e.POST("/configuration", func(c echo.Context) error {
		type body struct {
			Proxies string `json:"proxies"`
			UAs     string `json:"uas"`
		}
		var b body
		if err := c.Bind(&b); err != nil {
			return err
		}
		if b.Proxies != "" {
			if data, err := base64.StdEncoding.DecodeString(b.Proxies); err == nil {
				_ = osWriteFileSafe(cfg.ProxiesFile, data)
			}
		}
		if b.UAs != "" {
			if data, err := base64.StdEncoding.DecodeString(b.UAs); err == nil {
				_ = osWriteFileSafe(cfg.UserAgentsFile, data)
			}
		}
		return c.String(http.StatusOK, "OK")
	})

	// Static file serving
	staticDirs := []string{
		filepath.Join("bin", "web-client"),
		filepath.Join("web-client", "dist"),
	}
	mounted := false
	for _, dir := range staticDirs {
		if fi, err := os.Stat(dir); err == nil && fi.IsDir() {
			e.Static("/", dir)
			indexPath := filepath.Join(dir, "index.html")
			if _, err := os.Stat(indexPath); err == nil {
				e.File("/", indexPath)
			}
			log.Info().Msgf("Serving static files from %s", dir)
			mounted = true
			break
		}
	}
	if !mounted {
		log.Warn().Msg("Static web assets not found (bin/web-client or web-client/dist). Panel will be unavailable.")
	}

	log.Info().Msgf("Server listening on :%d", cfg.ServerPort)
	if err := e.Start(":" + intToString(cfg.ServerPort)); err != nil {
		log.Fatal().Err(err).Msg("server error")
	}
}

func osReadFileSafe(p string) ([]byte, error) {
	b, err := os.ReadFile(p)
	if err != nil {
		return []byte(""), nil
	}
	return b, nil
}

func osWriteFileSafe(p string, b []byte) error {
	return os.WriteFile(p, b, 0o644)
}

func intToString(i int) string { return fmt.Sprintf("%d", i) }
